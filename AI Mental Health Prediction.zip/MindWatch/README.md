# MindWatch - AI Mental Health Analyzer

A modern React application for AI-powered mental health analysis, built with React, TypeScript, Tailwind CSS, and shadcn/ui.

## Features

- 🤖 **AI-Powered Analysis**: Get instant insights into your mental well-being
- 🎨 **Modern UI**: Beautiful, responsive design built with shadcn/ui and Tailwind CSS
- 🔒 **Privacy First**: Your data is processed securely and never stored
- 📊 **Personalized Insights**: Receive tailored recommendations based on your input
- ⚡ **Fast & Responsive**: Built with Vite for optimal performance

## Tech Stack

- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - High-quality React components
- **Lucide React** - Beautiful icons

## Getting Started

### Prerequisites

- Node.js 18+ and npm/yarn/pnpm

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open your browser and navigate to `http://localhost:5173`

### Build for Production

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```

## Project Structure

```
MindWatch/
├── src/
│   ├── components/
│   │   └── ui/          # shadcn/ui components
│   ├── lib/
│   │   └── utils.ts     # Utility functions
│   ├── App.tsx          # Main application component
│   ├── main.tsx         # Application entry point
│   └── index.css        # Global styles
├── public/              # Static assets
├── index.html           # HTML template
├── package.json         # Dependencies and scripts
├── tailwind.config.js   # Tailwind configuration
├── tsconfig.json        # TypeScript configuration
└── vite.config.ts       # Vite configuration
```

## Usage

1. Enter your thoughts, feelings, or concerns in the text area
2. Click "Analyze Mental Health" to get AI-powered insights
3. Review your personalized analysis, including:
   - Overall well-being score
   - Risk level assessment
   - Key insights
   - Personalized recommendations

## Disclaimer

MindWatch is an AI-powered tool for informational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. If you're experiencing a mental health crisis, please contact a healthcare professional or emergency services immediately.

## License

MIT

