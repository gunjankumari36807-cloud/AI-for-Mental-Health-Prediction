import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Button } from './button';
import { X, ExternalLink, AlertCircle, Clock, Activity, FileText, ArrowLeft } from 'lucide-react';
import { cn } from '../../lib/utils';
import { useNavigate } from 'react-router-dom';

interface InsightViewProps {
  content: string;
  onClose?: () => void;
}

interface InsightMetadata {
  problemLevel?: string;
  severity?: string;
  urgency?: string;
  keyFindings?: string[];
  actionTimeline?: string;
}

function parseMetadata(content: string): { metadata: InsightMetadata; remainingContent: string } {
  const metadata: InsightMetadata = {};
  let remainingContent = content;

  // Extract Problem Level
  const problemLevelMatch = content.match(/## Problem Level:\s*(\w+)/i);
  if (problemLevelMatch) {
    metadata.problemLevel = problemLevelMatch[1].toUpperCase();
  }

  // Extract Severity
  const severityMatch = content.match(/\*\*Severity:\*\*\s*(\w+)/i);
  if (severityMatch) {
    metadata.severity = severityMatch[1];
  }

  // Extract Urgency
  const urgencyMatch = content.match(/\*\*Urgency:\*\*\s*(\w+)/i);
  if (urgencyMatch) {
    metadata.urgency = urgencyMatch[1];
  }

  // Extract Key Findings
  const keyFindingsMatch = content.match(/\*\*Key Findings:\*\*\s*([\s\S]*?)(?=\*\*|##|---|$)/i);
  if (keyFindingsMatch) {
    const findingsText = keyFindingsMatch[1];
    metadata.keyFindings = findingsText
      .split('\n')
      .map(line => line.replace(/^[-*]\s*/, '').trim())
      .filter(line => line.length > 0);
  }

  // Extract Action Timeline
  const actionTimelineMatch = content.match(/\*\*Recommended Action Timeline:\*\*\s*([^\n]+)/i);
  if (actionTimelineMatch) {
    metadata.actionTimeline = actionTimelineMatch[1].trim();
  }

  // Remove metadata section from remaining content
  const metadataEndMatch = content.match(/---/);
  if (metadataEndMatch && metadataEndMatch.index !== undefined) {
    remainingContent = content.substring(metadataEndMatch.index + 3).trim();
  }

  return { metadata, remainingContent };
}

function getProblemLevelStyles(level?: string) {
  switch (level) {
    case 'CRITICAL':
      return {
        bg: 'bg-red-500/10 dark:bg-red-500/20',
        border: 'border-red-500/50',
        text: 'text-red-600 dark:text-red-400',
        badge: 'bg-red-500 text-white',
      };
    case 'HIGH':
      return {
        bg: 'bg-orange-500/10 dark:bg-orange-500/20',
        border: 'border-orange-500/50',
        text: 'text-orange-600 dark:text-orange-400',
        badge: 'bg-orange-500 text-white',
      };
    case 'MODERATE':
      return {
        bg: 'bg-yellow-500/10 dark:bg-yellow-500/20',
        border: 'border-yellow-500/50',
        text: 'text-yellow-600 dark:text-yellow-400',
        badge: 'bg-yellow-500 text-white',
      };
    case 'NORMAL':
      return {
        bg: 'bg-blue-500/10 dark:bg-blue-500/20',
        border: 'border-blue-500/50',
        text: 'text-blue-600 dark:text-blue-400',
        badge: 'bg-blue-500 text-white',
      };
    case 'LOW':
      return {
        bg: 'bg-green-500/10 dark:bg-green-500/20',
        border: 'border-green-500/50',
        text: 'text-green-600 dark:text-green-400',
        badge: 'bg-green-500 text-white',
      };
    default:
      return {
        bg: 'bg-muted',
        border: 'border-border',
        text: 'text-foreground',
        badge: 'bg-muted text-foreground',
      };
  }
}

function getSeverityStyles(severity?: string) {
  switch (severity?.toLowerCase()) {
    case 'severe':
      return 'text-red-600 dark:text-red-400';
    case 'moderate':
      return 'text-orange-600 dark:text-orange-400';
    case 'mild':
      return 'text-yellow-600 dark:text-yellow-400';
    case 'minimal':
      return 'text-green-600 dark:text-green-400';
    default:
      return 'text-foreground';
  }
}

function getUrgencyStyles(urgency?: string) {
  switch (urgency?.toLowerCase()) {
    case 'immediate':
      return 'text-red-600 dark:text-red-400';
    case 'high':
      return 'text-orange-600 dark:text-orange-400';
    case 'moderate':
      return 'text-yellow-600 dark:text-yellow-400';
    case 'low':
    case 'routine':
      return 'text-blue-600 dark:text-blue-400';
    default:
      return 'text-foreground';
  }
}

export function InsightView({ content, onClose }: InsightViewProps) {
  const navigate = useNavigate();
  const { metadata, remainingContent } = parseMetadata(content);
  const hasMetadata = metadata.problemLevel || metadata.severity || metadata.urgency;
  const styles = getProblemLevelStyles(metadata.problemLevel);

  const handleClose = () => {
    if (onClose) {
      onClose();
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClose}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className="lg:hidden"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="max-w-4xl mx-auto px-6 py-8">
        
        {hasMetadata && (
          <div className={cn('rounded-lg border-2 p-6 mb-6', styles.bg, styles.border)}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <AlertCircle className={cn('h-6 w-6', styles.text)} />
                <h2 className={cn('text-2xl font-bold', styles.text)}>Clinical Assessment</h2>
              </div>
              {metadata.problemLevel && (
                <span className={cn('px-3 py-1 rounded-full text-sm font-semibold uppercase', styles.badge)}>
                  {metadata.problemLevel}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              {metadata.severity && (
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Severity:</span>
                  <span className={cn('text-sm font-semibold', getSeverityStyles(metadata.severity))}>
                    {metadata.severity}
                  </span>
                </div>
              )}
              {metadata.urgency && (
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Urgency:</span>
                  <span className={cn('text-sm font-semibold', getUrgencyStyles(metadata.urgency))}>
                    {metadata.urgency}
                  </span>
                </div>
              )}
            </div>

            {metadata.keyFindings && metadata.keyFindings.length > 0 && (
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-semibold text-foreground">Key Findings:</span>
                </div>
                <ul className="list-disc list-inside space-y-1 ml-6">
                  {metadata.keyFindings.map((finding, index) => (
                    <li key={index} className="text-sm text-foreground/90">
                      {finding}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {metadata.actionTimeline && (
              <div className="flex items-center gap-2 pt-3 border-t border-border/50">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-muted-foreground">Recommended Action Timeline:</span>
                <span className="text-sm font-semibold text-foreground">{metadata.actionTimeline}</span>
              </div>
            )}
          </div>
        )}

        <div className="prose prose-lg dark:prose-invert max-w-none">
          <ReactMarkdown
            components={{
              // Headers with enhanced styling
              h1: ({ node, ...props }) => (
                <h1 className="text-3xl font-bold mt-8 mb-4 text-foreground border-b border-border pb-2" {...props} />
              ),
              h2: ({ node, ...props }) => (
                <h2 className="text-2xl font-semibold mt-8 mb-4 text-foreground border-b border-border/50 pb-2 flex items-center gap-2" {...props} />
              ),
              h3: ({ node, ...props }) => (
                <h3 className="text-xl font-semibold mt-6 mb-3 text-foreground" {...props} />
              ),
              h4: ({ node, ...props }) => (
                <h4 className="text-lg font-semibold mt-5 mb-2 text-foreground" {...props} />
              ),
              h5: ({ node, ...props }) => (
                <h5 className="text-base font-semibold mt-4 mb-2 text-foreground" {...props} />
              ),
              h6: ({ node, ...props }) => (
                <h6 className="text-sm font-semibold mt-3 mb-2 text-foreground/80" {...props} />
              ),
              
              // Paragraphs with improved readability
              p: ({ node, ...props }) => (
                <p className="mb-4 text-foreground/90 leading-relaxed text-base" {...props} />
              ),
              
              // Lists with better spacing and nesting support
              ul: ({ node, ...props }) => (
                <ul className="list-disc list-outside mb-4 space-y-2 text-foreground/90 ml-6 marker:text-primary" {...props} />
              ),
              ol: ({ node, ...props }) => (
                <ol className="list-decimal list-outside mb-4 space-y-2 text-foreground/90 ml-6 marker:text-primary marker:font-semibold" {...props} />
              ),
              li: ({ node, ...props }) => {
                const children = React.Children.toArray(props.children);
                const hasNestedList = children.some(
                  (child: any) => child?.props?.node?.tagName === 'ul' || child?.props?.node?.tagName === 'ol'
                );
                return (
                  <li className={`text-foreground/90 ${hasNestedList ? 'mb-2' : ''} leading-relaxed`} {...props} />
                );
              },
              
              // Text formatting
              strong: ({ node, ...props }) => (
                <strong className="font-semibold text-foreground" {...props} />
              ),
              em: ({ node, ...props }) => (
                <em className="italic text-foreground/80" {...props} />
              ),
              
              // Code blocks and inline code
              code: ({ node, inline, className, children, ...props }: any) => {
                return !inline ? (
                  <pre className="bg-muted/50 border border-border rounded-lg p-4 my-4 overflow-x-auto">
                    <code className={`text-sm font-mono text-foreground block ${className || ''}`} {...props}>
                      {children}
                    </code>
                  </pre>
                ) : (
                  <code className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono text-foreground border border-border/50" {...props}>
                    {children}
                  </code>
                );
              },
              
              // Blockquotes with enhanced styling for important information
              blockquote: ({ node, ...props }) => (
                <blockquote className="border-l-4 border-primary/60 bg-primary/5 pl-4 py-3 pr-4 my-4 rounded-r-md text-foreground/90 italic relative" {...props} />
              ),
              
              // Links with icons
              a: ({ node, href, children, ...props }: any) => {
                const isExternal = href?.startsWith('http');
                return (
                  <a
                    href={href}
                    target={isExternal ? '_blank' : undefined}
                    rel={isExternal ? 'noopener noreferrer' : undefined}
                    className="text-primary hover:text-primary/80 underline underline-offset-2 font-medium inline-flex items-center gap-1 transition-colors"
                    {...props}
                  >
                    {children}
                    {isExternal && <ExternalLink className="h-3 w-3" />}
                  </a>
                );
              },
              
              // Horizontal rules
              hr: ({ node, ...props }) => (
                <hr className="my-6 border-t border-border" {...props} />
              ),
              
              // Tables for clinical data
              table: ({ node, ...props }) => (
                <div className="overflow-x-auto my-6">
                  <table className="min-w-full border-collapse border border-border rounded-lg" {...props} />
                </div>
              ),
              thead: ({ node, ...props }) => (
                <thead className="bg-muted" {...props} />
              ),
              tbody: ({ node, ...props }) => (
                <tbody className="divide-y divide-border" {...props} />
              ),
              tr: ({ node, ...props }) => (
                <tr className="hover:bg-muted/50 transition-colors" {...props} />
              ),
              th: ({ node, ...props }) => (
                <th className="border border-border px-4 py-3 text-left font-semibold text-foreground bg-muted/50" {...props} />
              ),
              td: ({ node, ...props }) => (
                <td className="border border-border px-4 py-3 text-foreground/90" {...props} />
              ),
              
              // Images
              img: ({ node, src, alt, ...props }: any) => (
                <img
                  src={src}
                  alt={alt}
                  className="rounded-lg my-4 max-w-full h-auto border border-border shadow-sm"
                  {...props}
                />
              ),
            }}
          >
            {remainingContent || content}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}

