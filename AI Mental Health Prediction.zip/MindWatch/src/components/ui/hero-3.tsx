import React from 'react'
import { ArrowRight, ChevronRight, Menu, X, Loader2 } from 'lucide-react'
import { Button } from './button'
import { AnimatedGroup } from './animated-group'
import { cn } from '../../lib/utils'
import { ThemeToggle } from '../theme-toggle'
import { Footer } from './footer'
import {
  DialogStack,
  DialogStackTrigger,
  DialogStackOverlay,
  DialogStackBody,
  DialogStackContent,
  DialogStackHeader,
  DialogStackTitle,
  DialogStackDescription,
  DialogStackFooter,
  DialogStackNext,
} from '../kibo-ui/dialog-stack'
import { useEffect } from 'react'
import { Textarea } from './textarea'
import { getAIResponse } from '../../lib/ai-service'
import { useNavigate } from 'react-router-dom'

const DialogAdvancer = ({ currentQuestion }: { currentQuestion: string }) => {
    const [nextButton, setNextButton] = React.useState<HTMLButtonElement | null>(null)
    
    useEffect(() => {
        if (currentQuestion && nextButton) {
            // Wait for the new DialogStackContent to be added and totalDialogs to update
            const timer = setTimeout(() => {
                if (nextButton && !nextButton.disabled) {
                    nextButton.click()
                } else {
                    // Retry after a bit more time
                    setTimeout(() => {
                        if (nextButton && !nextButton.disabled) {
                            nextButton.click()
                        }
                    }, 200)
                }
            }, 400)
            
            return () => clearTimeout(timer)
        }
    }, [currentQuestion, nextButton])
    
    return (
        <div style={{ position: 'absolute', opacity: 0, pointerEvents: 'none', width: 0, height: 0 }}>
            <DialogStackNext asChild>
                <Button ref={setNextButton} style={{ display: 'none' }}>Hidden</Button>
            </DialogStackNext>
        </div>
    )
}

const transitionVariants = {
    item: {
        hidden: {
            opacity: 0,
            filter: 'blur(12px)',
            y: 12,
        },
        visible: {
            opacity: 1,
            filter: 'blur(0px)',
            y: 0,
            transition: {
                type: 'spring' as const,
                bounce: 0.3,
                duration: 1.5,
            },
        },
    },
}

export function LandingPage() {
    const navigate = useNavigate()
    const [feeling, setFeeling] = React.useState('')
    const [isLoading, setIsLoading] = React.useState(false)
    const [conversationHistory, setConversationHistory] = React.useState<string[]>([])
    const [followUpQuestions, setFollowUpQuestions] = React.useState<Array<{ question: string; answer: string }>>([])
    const [currentQuestion, setCurrentQuestion] = React.useState<string>('')
    const [currentAnswer, setCurrentAnswer] = React.useState<string>('')
    const [error, setError] = React.useState<string | null>(null)
    const [isDialogOpen, setIsDialogOpen] = React.useState(false)

    const handleDialogOpenChange = React.useCallback((open: boolean) => {
        setIsDialogOpen(open)
        if (!open) {
            // Reset all form inputs when dialog is closed
            setFeeling('')
            setConversationHistory([])
            setFollowUpQuestions([])
            setCurrentQuestion('')
            setCurrentAnswer('')
            setError(null)
        }
    }, [])

    const handleContinue = React.useCallback(async (userInput: string) => {
        if (!userInput.trim()) return

        setIsLoading(true)
        setError(null)

        try {
            // Build conversation history
            const history = [
                `User: ${userInput}`,
                ...conversationHistory,
            ]

            // Get AI response
            const response = await getAIResponse(userInput, conversationHistory)

            if (response.type === 'question') {
                // Show follow-up question
                setCurrentQuestion(response.content)
                setCurrentAnswer('')
                setConversationHistory([...history])
            } else {
                // Navigate to insight page
                setConversationHistory([])
                setFollowUpQuestions([])
                // Close dialog stack when showing insight
                setIsDialogOpen(false)
                // Navigate to insight page with content
                navigate('/insight', { state: { content: response.content } })
            }
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Failed to get AI response. Please try again.'
            setError(errorMessage)
        } finally {
            setIsLoading(false)
        }
    }, [conversationHistory])

    const handleAnswerFollowUp = React.useCallback(async () => {
        if (!currentAnswer.trim()) return

        setIsLoading(true)
        setError(null)

        try {
            // Add question and answer to history
            const newFollowUp = { question: currentQuestion, answer: currentAnswer }
            const updatedFollowUps = [...followUpQuestions, newFollowUp]
            setFollowUpQuestions(updatedFollowUps)

            // Build conversation history with all Q&As
            const history = conversationHistory.concat([
                `AI: ${currentQuestion}`,
                `User: ${currentAnswer}`,
            ])

            // Get AI response
            const response = await getAIResponse(currentAnswer, history)

            if (response.type === 'question') {
                // Show another follow-up question
                setCurrentQuestion(response.content)
                setCurrentAnswer('')
                setConversationHistory(history)
                // Dialog will automatically show the new question since it's in the array
            } else {
                // Navigate to insight page
                setConversationHistory([])
                setFollowUpQuestions([])
                // Close dialog stack when showing insight
                setIsDialogOpen(false)
                // Navigate to insight page with content
                navigate('/insight', { state: { content: response.content } })
            }
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Failed to get AI response. Please try again.'
            setError(errorMessage)
        } finally {
            setIsLoading(false)
        }
    }, [currentAnswer, currentQuestion, conversationHistory, followUpQuestions])

    const dialogContents = React.useMemo(() => {
        const contents = [
            <DialogStackContent key="welcome">
                <DialogStackHeader>
                    <DialogStackTitle>Welcome to MindWatch</DialogStackTitle>
                    <DialogStackDescription>
                        Get started with AI-powered mental health analysis. Share your thoughts and receive personalized insights.
                    </DialogStackDescription>
                </DialogStackHeader>
                <DialogStackFooter>
                    <DialogStackNext asChild>
                        <Button>Get Started</Button>
                    </DialogStackNext>
                </DialogStackFooter>
            </DialogStackContent>,
            <DialogStackContent key="feeling">
                <DialogAdvancer currentQuestion={currentQuestion} />
                <DialogStackHeader>
                    <DialogStackTitle>How are you feeling today?</DialogStackTitle>
                    <DialogStackDescription>
                        Take a moment to reflect and share how you're feeling right now. There are no right or wrong answers.
                    </DialogStackDescription>
                </DialogStackHeader>
                <div className="mt-4">
                    <Textarea
                        placeholder="Share your thoughts, feelings, or emotions..."
                        value={feeling}
                        onChange={(e) => setFeeling(e.target.value)}
                        className="min-h-[120px]"
                    />
                </div>
                <DialogStackFooter>
                    <Button 
                        disabled={!feeling.trim() || isLoading}
                        onClick={() => handleContinue(feeling)}
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            'Continue'
                        )}
                    </Button>
                </DialogStackFooter>
                {error && (
                    <div className="mt-4 p-3 text-sm text-destructive bg-destructive/10 rounded-md">
                        {error}
                    </div>
                )}
            </DialogStackContent>,
        ]

        if (currentQuestion) {
            contents.push(
                <DialogStackContent key="followup">
                    <DialogStackHeader>
                        <DialogStackTitle>Follow-up Question</DialogStackTitle>
                        <DialogStackDescription>
                            {currentQuestion}
                        </DialogStackDescription>
                    </DialogStackHeader>
                    <div className="mt-4">
                        <Textarea
                            placeholder="Your answer..."
                            value={currentAnswer}
                            onChange={(e) => setCurrentAnswer(e.target.value)}
                            className="min-h-[120px]"
                        />
                    </div>
                    <DialogStackFooter>
                        <Button 
                            disabled={!currentAnswer.trim() || isLoading}
                            onClick={handleAnswerFollowUp}
                        >
                            {isLoading ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                'Continue'
                            )}
                        </Button>
                    </DialogStackFooter>
                    {error && (
                        <div className="mt-4 p-3 text-sm text-destructive bg-destructive/10 rounded-md">
                            {error}
                        </div>
                    )}
                </DialogStackContent>
            )
        }

        return contents
    }, [feeling, isLoading, error, currentQuestion, currentAnswer, handleContinue, handleAnswerFollowUp])

    return (
        <DialogStack open={isDialogOpen} onOpenChange={handleDialogOpenChange}>
            <HeroHeader />
            <DialogStackOverlay />
            <DialogStackBody>
                {dialogContents}
            </DialogStackBody>
            <main className="overflow-hidden">
                <div
                    aria-hidden
                    className="z-[2] absolute inset-0 pointer-events-none isolate opacity-50 contain-strict hidden lg:block">
                    <div className="w-[35rem] h-[80rem] -translate-y-[350px] absolute left-0 top-0 -rotate-45 rounded-full bg-[radial-gradient(68.54%_68.72%_at_55.02%_31.46%,hsla(0,0%,85%,.08)_0,hsla(0,0%,55%,.02)_50%,hsla(0,0%,45%,0)_80%)]" />
                    <div className="h-[80rem] absolute left-0 top-0 w-56 -rotate-45 rounded-full bg-[radial-gradient(50%_50%_at_50%_50%,hsla(0,0%,85%,.06)_0,hsla(0,0%,45%,.02)_80%,transparent_100%)] [translate:5%_-50%]" />
                    <div className="h-[80rem] -translate-y-[350px] absolute left-0 top-0 w-56 -rotate-45 bg-[radial-gradient(50%_50%_at_50%_50%,hsla(0,0%,85%,.04)_0,hsla(0,0%,45%,.02)_80%,transparent_100%)]" />
                </div>
                <section>
                    <div className="relative pt-24 md:pt-36">
                        <div aria-hidden className="absolute inset-0 -z-10 size-full [background:radial-gradient(125%_125%_at_50%_100%,transparent_0%,var(--background)_75%)]" />
                        <div className="mx-auto max-w-7xl px-6">
                            <div className="text-center sm:mx-auto lg:mr-auto lg:mt-0">
                                <AnimatedGroup variants={transitionVariants}>
                                    <a
                                        href="#features"
                                        className="hover:bg-background dark:hover:border-t-border bg-muted group mx-auto flex w-fit items-center gap-4 rounded-full border p-1 pl-4 shadow-md shadow-black/5 transition-all duration-300 dark:border-t-white/5 dark:shadow-zinc-950">
                                        <span className="text-foreground text-sm">AI-Powered Mental Health Analyzer</span>
                                        <span className="dark:border-background block h-4 w-0.5 border-l bg-white dark:bg-zinc-700"></span>

                                        <div className="bg-background group-hover:bg-muted size-6 overflow-hidden rounded-full duration-500">
                                            <div className="flex w-12 -translate-x-1/2 duration-500 ease-in-out group-hover:translate-x-0">
                                                <span className="flex size-6">
                                                    <ArrowRight className="m-auto size-3" />
                                                </span>
                                                <span className="flex size-6">
                                                    <ArrowRight className="m-auto size-3" />
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                        
                                    <h1
                                        className="mt-8 max-w-4xl mx-auto font-semibold text-balance text-5xl md:text-6xl lg:mt-16 xl:text-[5rem]">
                                        Your Mental Health Journey Starts Here
                                    </h1>
                                    <p
                                        className="mx-auto mt-8 opacity-60 max-w-2xl text-balance text-lg">
                                        Get instant AI-powered insights into your mental well-being. Share your thoughts and receive personalized analysis and recommendations.
                                    </p>
                                </AnimatedGroup>

                                <AnimatedGroup
                                    variants={{
                                        container: {
                                            visible: {
                                                transition: {
                                                    staggerChildren: 0.05,
                                                    delayChildren: 0.75,
                                                },
                                            },
                                        },
                                        ...transitionVariants,
                                    }}
                                    className="mt-12 flex flex-col items-center justify-center gap-2 md:flex-row">
                                    <div
                                        key={1}
                                        className="bg-foreground/10 rounded-full border p-0.5">
                                        <DialogStackTrigger asChild>
                                            <Button
                                                size="lg"
                                                className="rounded-full px-5 text-base">
                                                <span className="text-nowrap">Get Started</span>
                                            </Button>
                                        </DialogStackTrigger>
                                    </div>
                                    <Button
                                        key={2}
                                        asChild
                                        size="lg"
                                        variant="ghost"
                                        className="h-10.5 rounded-full px-5 py-2">
                                        <a href="#learn-more">
                                            <span className="text-nowrap">Learn More</span>
                                        </a>
                                    </Button>
                                </AnimatedGroup>
                            </div>
                        </div>

                        <AnimatedGroup
                            variants={{
                                container: {
                                    visible: {
                                        transition: {
                                            staggerChildren: 0.05,
                                            delayChildren: 0.75,
                                        },
                                    },
                                },
                                ...transitionVariants,
                            }}>
                            <div className="relative -mr-56 mt-8 overflow-hidden px-2 sm:mr-0 sm:mt-12 md:mt-20">
                                <div
                                    aria-hidden
                                    className="bg-gradient-to-b to-background absolute inset-0 z-10 from-transparent from-35%"
                                />
                                <div className="inset-shadow-2xs ring-background dark:inset-shadow-white/20 bg-background relative mx-auto max-w-6xl overflow-hidden rounded-2xl border p-4 shadow-lg shadow-zinc-950/15 ring-1">
                                    <img
                                        className="bg-background aspect-15/8 relative hidden rounded-2xl dark:block"
                                        src="https://tailark.com//_next/image?url=%2Fmail2.png&w=3840&q=75"
                                        alt="app screen"
                                        width="2700"
                                        height="1440"
                                    />
                                    <img
                                        className="z-2 border-border/25 aspect-15/8 relative rounded-2xl border dark:hidden"
                                        src="https://tailark.com/_next/image?url=%2Fmail2-light.png&w=3840&q=75"
                                        alt="app screen"
                                        width="2700"
                                        height="1440"
                                    />
                                </div>
                            </div>
                        </AnimatedGroup>
                    </div>
                </section>
                <section className="bg-background pb-16 pt-16 md:pb-32">
                    <div className="group relative m-auto max-w-5xl px-6">
                        <div className="absolute inset-0 z-10 flex scale-95 items-center justify-center opacity-0 duration-500 group-hover:scale-100 group-hover:opacity-100">
                            <a
                                href="#partners"
                                className="block text-sm duration-150 hover:opacity-75">
                                <span> Meet Our Partners</span>

                                <ChevronRight className="ml-1 inline-block size-3" />
                            </a>
                        </div>
                        <div className="group-hover:blur-xs mx-auto mt-12 grid max-w-2xl grid-cols-4 gap-x-12 gap-y-8 transition-all duration-500 group-hover:opacity-50 sm:gap-x-16 sm:gap-y-14">
                            <div className="flex">
                                <img
                                    className="mx-auto h-5 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/nvidia.svg"
                                    alt="Nvidia Logo"
                                    height="20"
                                    width="auto"
                                />
                            </div>

                            <div className="flex">
                                <img
                                    className="mx-auto h-4 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/column.svg"
                                    alt="Column Logo"
                                    height="16"
                                    width="auto"
                                />
                            </div>
                            <div className="flex">
                                <img
                                    className="mx-auto h-4 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/github.svg"
                                    alt="GitHub Logo"
                                    height="16"
                                    width="auto"
                                />
                            </div>
                            <div className="flex">
                                <img
                                    className="mx-auto h-5 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/nike.svg"
                                    alt="Nike Logo"
                                    height="20"
                                    width="auto"
                                />
                            </div>
                            <div className="flex">
                                <img
                                    className="mx-auto h-5 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/lemonsqueezy.svg"
                                    alt="Lemon Squeezy Logo"
                                    height="20"
                                    width="auto"
                                />
                            </div>
                            <div className="flex">
                                <img
                                    className="mx-auto h-4 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/laravel.svg"
                                    alt="Laravel Logo"
                                    height="16"
                                    width="auto"
                                />
                            </div>
                            <div className="flex">
                                <img
                                    className="mx-auto h-7 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/lilly.svg"
                                    alt="Lilly Logo"
                                    height="28"
                                    width="auto"
                                />
                            </div>

                            <div className="flex">
                                <img
                                    className="mx-auto h-6 w-fit dark:invert"
                                    src="https://html.tailus.io/blocks/customers/openai.svg"
                                    alt="OpenAI Logo"
                                    height="24"
                                    width="auto"
                                />
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <Footer />
        </DialogStack>
    )
}

const menuItems = [
    { name: 'Features', href: '#features' },
    { name: 'How It Works', href: '#how-it-works' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'About', href: '#about' },
]

const HeroHeader = () => {
    const [menuState, setMenuState] = React.useState(false)
    const [isScrolled, setIsScrolled] = React.useState(false)

    React.useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50)
        }
        window.addEventListener('scroll', handleScroll)
        return () => window.removeEventListener('scroll', handleScroll)
    }, [])
    return (
        <header>
            <nav
                data-state={menuState && 'active'}
                className="fixed z-20 w-full px-2 group">
                <div className={cn('mx-auto mt-2 max-w-6xl px-6 transition-all duration-300 lg:px-12', isScrolled && 'bg-background/50 max-w-4xl rounded-2xl border backdrop-blur-lg lg:px-5')}>
                    <div className="relative flex flex-wrap items-center justify-between gap-6 py-3 lg:gap-0 lg:py-4">
                        <div className="flex w-full justify-between lg:w-auto">
                            <a
                                href="/"
                                aria-label="home"
                                className="flex items-center space-x-2">
                                <Logo />
                            </a>

                            <button
                                onClick={() => setMenuState(!menuState)}
                                aria-label={menuState == true ? 'Close Menu' : 'Open Menu'}
                                className="relative z-20 -m-2.5 -mr-4 block cursor-pointer p-2.5 lg:hidden">
                                <Menu className="in-data-[state=active]:rotate-180 group-data-[state=active]:scale-0 group-data-[state=active]:opacity-0 m-auto size-6 duration-200" />
                                <X className="group-data-[state=active]:rotate-0 group-data-[state=active]:scale-100 group-data-[state=active]:opacity-100 absolute inset-0 m-auto size-6 -rotate-180 scale-0 opacity-0 duration-200" />
                            </button>
                        </div>

                        <div className="absolute inset-0 m-auto hidden size-fit lg:block">
                            <ul className="flex gap-8 text-sm">
                                {menuItems.map((item, index) => (
                                    <li key={index}>
                                        <a
                                            href={item.href}
                                            className="text-muted-foreground hover:text-accent-foreground block duration-150">
                                            <span>{item.name}</span>
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <div className="hidden lg:flex items-center gap-4">
                            <ThemeToggle />
                            <Button
                                asChild
                                variant="outline"
                                size="sm"
                                className={cn(!isScrolled ? 'inline-flex rounded-full' : 'hidden')}>
                                <a href="#login">
                                    <span>Login</span>
                                </a>
                            </Button>
                            <Button
                                asChild
                                size="sm"
                                className={cn(!isScrolled ? 'inline-flex rounded-full' : 'hidden')}>
                                <a href="#signup">
                                    <span>Sign Up</span>
                                </a>
                            </Button>
                            <DialogStackTrigger asChild>
                                <Button
                                    size="sm"
                                    className={cn(isScrolled ? 'inline-flex rounded-full' : 'hidden')}>
                                    <span>Get Started</span>
                                </Button>
                            </DialogStackTrigger>
                        </div>

                        <div className="bg-background group-data-[state=active]:block mb-6 hidden w-full flex-wrap items-center justify-end space-y-8 rounded-3xl border p-6 shadow-2xl shadow-zinc-300/20 md:flex-nowrap lg:hidden dark:shadow-none">
                            <div>
                                <ul className="space-y-6 text-base">
                                    {menuItems.map((item, index) => (
                                        <li key={index}>
                                            <a
                                                href={item.href}
                                                className="text-muted-foreground hover:text-accent-foreground block duration-150">
                                                <span>{item.name}</span>
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="flex w-full items-center gap-3 flex-col space-y-3 sm:flex-row sm:gap-3 sm:space-y-0 md:w-fit">
                                <ThemeToggle />
                                <Button
                                    asChild
                                    variant="outline"
                                    size="sm">
                                    <a href="#login">
                                        <span>Login</span>
                                    </a>
                                </Button>
                                <Button
                                    asChild
                                    size="sm">
                                    <a href="#signup">
                                        <span>Sign Up</span>
                                    </a>
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    )
}

const Logo = ({ className }: { className?: string }) => {
    return (
        <div className={cn('flex items-center space-x-2', className)}>
            <svg
                viewBox="0 0 18 18"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5">
                <path
                    d="M3 0H5V18H3V0ZM13 0H15V18H13V0ZM18 3V5H0V3H18ZM0 15V13H18V15H0Z"
                    fill="url(#logo-gradient)"
                />
                <defs>
                    <linearGradient
                        id="logo-gradient"
                        x1="10"
                        y1="0"
                        x2="10"
                        y2="20"
                        gradientUnits="userSpaceOnUse">
                        <stop stopColor="#9B99FE" />
                        <stop
                            offset="1"
                            stopColor="#2BC8B7"
                        />
                    </linearGradient>
                </defs>
            </svg>
            <span className="font-semibold text-lg bg-gradient-to-r from-[#9B99FE] to-[#2BC8B7] bg-clip-text text-transparent">MindWatch</span>
        </div>
    )
}