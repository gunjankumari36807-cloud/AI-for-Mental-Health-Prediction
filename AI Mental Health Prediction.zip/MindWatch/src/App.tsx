import { HashRouter, Routes, Route } from 'react-router-dom'
import { LandingPage } from './components/ui/hero-3'
import { InsightPage } from './pages/InsightPage'
import { NotFoundPage } from './pages/NotFoundPage'

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/insight" element={<InsightPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </HashRouter>
  )
}

export default App