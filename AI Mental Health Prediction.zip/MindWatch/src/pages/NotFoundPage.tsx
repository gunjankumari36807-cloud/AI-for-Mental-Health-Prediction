import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { Button } from '../components/ui/button'
import { AnimatedGroup } from '../components/ui/animated-group'

const transitionVariants = {
    item: {
        hidden: {
            opacity: 0,
            filter: 'blur(12px)',
            y: 12,
        },
        visible: {
            opacity: 1,
            filter: 'blur(0px)',
            y: 0,
            transition: {
                type: 'spring' as const,
                bounce: 0.3,
                duration: 1.5,
            },
        },
    },
}

export function NotFoundPage() {
    const navigate = useNavigate()

    return (
        <main className="overflow-hidden min-h-screen flex items-center justify-center">
            <div
                aria-hidden
                className="z-[2] absolute inset-0 pointer-events-none isolate opacity-50 contain-strict hidden lg:block">
                <div className="w-[35rem] h-[80rem] -translate-y-[350px] absolute left-0 top-0 -rotate-45 rounded-full bg-[radial-gradient(68.54%_68.72%_at_55.02%_31.46%,hsla(0,0%,85%,.08)_0,hsla(0,0%,55%,.02)_50%,hsla(0,0%,45%,0)_80%)]" />
                <div className="h-[80rem] absolute left-0 top-0 w-56 -rotate-45 rounded-full bg-[radial-gradient(50%_50%_at_50%_50%,hsla(0,0%,85%,.06)_0,hsla(0,0%,45%,.02)_80%,transparent_100%)] [translate:5%_-50%]" />
                <div className="h-[80rem] -translate-y-[350px] absolute left-0 top-0 w-56 -rotate-45 bg-[radial-gradient(50%_50%_at_50%_50%,hsla(0,0%,85%,.04)_0,hsla(0,0%,45%,.02)_80%,transparent_100%)]" />
            </div>
            <section>
                <div className="relative">
                    <div aria-hidden className="absolute inset-0 -z-10 size-full [background:radial-gradient(125%_125%_at_50%_100%,transparent_0%,var(--background)_75%)]" />
                    <div className="mx-auto max-w-7xl px-6">
                        <div className="text-center sm:mx-auto lg:mr-auto lg:mt-0">
                            <AnimatedGroup variants={transitionVariants}>
                                <h2
                                    className="mt-8 max-w-4xl mx-auto font-semibold text-balance text-5xl md:text-6xl lg:mt-16 xl:text-[5rem]">
                                    Page Not Found
                                </h2>
                                <p
                                    className="mx-auto mt-8 opacity-60 max-w-2xl text-balance text-lg">
                                    The page you're looking for doesn't exist or has been moved. Let's get you back on track.
                                </p>
                            </AnimatedGroup>

                            <AnimatedGroup
                                variants={{
                                    container: {
                                        visible: {
                                            transition: {
                                                staggerChildren: 0.05,
                                                delayChildren: 0.75,
                                            },
                                        },
                                    },
                                    ...transitionVariants,
                                }}
                                className="mt-12 flex flex-col items-center justify-center gap-2 md:flex-row">
                                <div
                                    key={1}
                                    className="bg-foreground/10 rounded-full border p-0.5">
                                    <Button
                                        size="lg"
                                        className="rounded-full px-5 text-base"
                                        onClick={() => navigate('/')}>
                                        <ArrowLeft className="mr-2 h-4 w-4" />
                                        <span className="text-nowrap">Go Home</span>
                                    </Button>
                                </div>
                                <Button
                                    key={2}
                                    size="lg"
                                    variant="ghost"
                                    className="h-10.5 rounded-full px-5 py-2"
                                    onClick={() => window.history.back()}>
                                    <span className="text-nowrap">Go Back</span>
                                </Button>
                            </AnimatedGroup>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    )
}

