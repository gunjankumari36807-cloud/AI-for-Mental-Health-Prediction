import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InsightView } from '../components/ui/insight-view';

export function InsightPage() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get insight content from location state
  const insightContent = location.state?.content || null;

  React.useEffect(() => {
    // If no content, redirect to home
    if (!insightContent) {
      navigate('/');
    }
  }, [insightContent, navigate]);

  if (!insightContent) {
    return null;
  }

  return (
    <InsightView 
      content={insightContent} 
      onClose={() => navigate('/')} 
    />
  );
}

